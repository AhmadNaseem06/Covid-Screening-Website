# Building Screening App Challenge

## Challenge

> ### 🔗 Preview Challenge [Here](https://www.figma.com/file/Frs80hDJudAJ83SaTZljBf/COVID19-Screening-Test)

## Solution

<p align="center">
        <a href="#"><img alt="Bootstrap Design Conversion: App Challenge (Solution)"
                        src="https://i.postimg.cc/ZqsZzjT1/Bootstrap-Design-Conversion-App-Challenge.png" /></a>
</p>

> ### 🔗 Preview Solution [Here](https://replit.com/@RaCoHo/Building-Screening-App-Challenge)

## References

> ### 🔗 [Assets](https://drive.google.com/drive/folders/14jXeRS_Ww_HbvI7oKauFoBIap9bHPqXH)
>
> ### 🔗 [Challenge Preview](https://www.figma.com/file/Frs80hDJudAJ83SaTZljBf/COVID19-Screening-Test)
>
> ### 🔗 [Guidelines](https://gist.github.com/InternsSchool)
